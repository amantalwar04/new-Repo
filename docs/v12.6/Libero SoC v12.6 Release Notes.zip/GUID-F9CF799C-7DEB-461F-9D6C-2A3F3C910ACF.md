# Microchip FPGA Technical Support

Microchip FPGA Products Group backs its products with various support services, including Customer Service, Customer Technical Support Center, a website, and worldwide sales offices. This section provides information about contacting Microchip FPGA Products Group and using these support services.

-   **[Customer Service](GUID-CD4AD298-15F2-44A8-A734-EBEE3A9AF154.md)**  

-   **[Customer Technical Support](GUID-CBA128DE-8057-48D6-B166-CC98F5DEEEFC.md)**  

-   **[Website](GUID-5A785935-F95C-40F2-8658-BE331AF364D4.md)**  

-   **[Outside the U.S.](GUID-C18852E1-B6BB-4741-A0B9-98971D59F6F3.md)**  


